#!/bin/sh
ipset create cn hash:net
for ip in $(cat '/jffs/route/route.list'); do
    ipset add cn $ip
done